/**
 * 
 */
/**
 * 
 */
module exemplo.poo {
}