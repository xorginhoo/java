/**
 * 
 */
/**
 * 
 */
module exemplo_poo {
}