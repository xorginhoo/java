package aplicacao;
import java.util.Scanner;

public class Programa {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		Produto produto = new Produto();
		
		System.out.println("informe o seu produto");
		produto.produto = teclado.next();
		
		System.out.println("informe o seu quantidade");
		produto.quantidade = teclado.nextDouble();
		
		System.out.println("informe preço");
		produto.preco = teclado.nextDouble();
		
		
		System.out.println("confirmação: " + produto.produto + "\nestoque: " + produto.quantidade + "\npreço: " + produto.preco);
		
		System.out.println("Deseja inserir mais produtos? Quantos:\n");
		int estoque = teclado.nextInt();
		produto.addProduto (estoque);
		
		System.out.println("atualização: " + produto.produto + "\nestoque: " + produto.quantidade + "\npreço: " + produto.preco);
		
		System.out.println("atualmente, alguma venda foi realizada?");
		estoque = teclado.nextInt();
		produto.subProduto (estoque);
		
		System.out.println("atualização pós vendas: " + produto.produto + "\nestoque atual: " + produto.quantidade + "\npreço final: " + produto.preco);
		
		teclado.close();
	}

}
